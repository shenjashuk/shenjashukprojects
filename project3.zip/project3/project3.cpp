﻿// project3.cpp : Этот файл содержит функцию "main". Здесь начинается и заканчивается выполнение программы.
//

#include <iostream>
using namespace std;
int main()
{
	double f, c;
	int count;
	cin >> c;
	if (c >= -273) {
		cin >>count;
		if (count>c) {
			for (double i = c; i <= count;i++) {
				f = i * 9 / 5 + 32 ;
				cout << f << "\n";
			}
		}
		else {
			cout << "sorry, but I don't know what I can do with this item";
		}
	}
	else {
		cout << "sorry";
	}
}


