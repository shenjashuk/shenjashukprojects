﻿// ConsoleApplication1.cpp : Этот файл содержит функцию "main". Здесь начинается и заканчивается выполнение программы.
//

#include <iostream>
using namespace std;
int main()
{
	double f, c;
	cin >> c;
	f = c * 9 / 5 + 32;
	cout << f;
	return 0;
}


