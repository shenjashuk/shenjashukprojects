﻿// Project2.cpp : Этот файл содержит функцию "main". Здесь начинается и заканчивается выполнение программы.
//

#include <iostream>
using namespace std;
int main()
{
	double f, c;
	cin >> c;
	if (c>-273) {
		f = c * 9 / 5 + 32;
		cout << f;
	}
	else {
		cout << "sorry";
	}
	return 0;
}


